create definer = swcamp@`%` trigger after_order_menu_insert
    after insert
    on tbl_order_menu
    for each row
BEGIN
	UPDATE tbl_order -- tbl_oder_menu에 insert가 되면 tbl_oder를 update
	SET total_order_price = total_order_price + NEW.order_amount * (SELECT -- new : insert에서 가지고 있는 값
																								  menu_price
																							  FROM tbl_menu
																							 WHERE menu_code = NEW.menu_code)
	WHERE order_code = NEW.order_code;

END;

