create
    definer = swcamp@`%` function increasePrice(currPrice double, proportion double) returns double deterministic
BEGIN
	RETURN currPrice * (1 + proportion);
END;

