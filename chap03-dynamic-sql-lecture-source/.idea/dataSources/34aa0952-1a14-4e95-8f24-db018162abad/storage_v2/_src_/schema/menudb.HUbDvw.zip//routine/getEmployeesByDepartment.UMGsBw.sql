create
    definer = swcamp@`%` procedure getEmployeesByDepartment(IN dept char(2))
BEGIN
    SELECT emp_id, emp_name, salary
     FROM employee
	 WHERE dept_code = dept;
END;

