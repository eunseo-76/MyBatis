create
    definer = swcamp@`%` procedure addNumbers(IN num1 int, IN num2 int, OUT numSum int)
BEGIN
	DECLARE sumofnums INT DEFAULT 0;
	set sumofnums = num1 + num2;
	set numSum = sumofnums;
	-- 그냥 numSum = num1 + num2는 안 되는 이유?
END;

